import java.time.*;

import org.json.JSONException;

import java.io.*;

/*public class Test {
	public static void main(String[]args) {
		
		String base = "USD";
		String symbols = "MXN";
		LocalDate currentDate = LocalDate.now();
		LocalDate oneMonthAgo = LocalDate.now().minusMonths(1);
		LocalDate twoMonthsAgo = LocalDate.now().minusMonths(2);
		LocalDate threeMonthsAgo = LocalDate.now().minusMonths(3);
		LocalDate fourMonthsAgo = LocalDate.now().minusMonths(4);
		LocalDate fiveMonthsAgo = LocalDate.now().minusMonths(5);
		LocalDate sixMonthsAgo = LocalDate.now().minusMonths(6);
		
		
		
		try {
			ExchangeRates.getExchangeRatesHistory(base, symbols, currentDate);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}*/
